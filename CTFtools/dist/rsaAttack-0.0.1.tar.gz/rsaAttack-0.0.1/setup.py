import setuptools
 
setuptools.setup(
    name="rsaAttack",
    version="0.0.1",
    author="Arcueid",
    author_email="1340332267@qq.com",
    description="",
    long_description="rsaAttack",
    long_description_content_type="rsaAttack",
    url="",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)